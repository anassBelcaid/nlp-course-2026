# Project 03 · Neural Sequence Laboratory

The first guided notebook is `01_names_rnn.ipynb`. Students build the five
chapter-specific pieces of a character-level RNN while the data pipeline,
training infrastructure, evaluation, plotting, and tests are supplied.

## Local setup

```bash
uv sync
uv run jupyter lab 01_names_rnn.ipynb
```

The notebook can also be uploaded directly to Google Colab. On its first run,
it downloads and caches Karpathy's `names.txt` dataset as `babynames.txt`.

## Session 1 outcome

By the end of the notebook, students train a vanilla RNN and sample original
baby names at several temperatures.

